import { groq } from 'next-sanity'

export const projectsQuery = groq`*[_type == "project"] | order(_createdAt desc) {
  _id,
  title,
  slug,
  category,
  client,
  year,
  "coverImage": coverImage.asset->url,
  "gallery": gallery[].asset->url,
  videoUrl,
  summary,
  description,
  featured
}`

export const featuredProjectsQuery = groq`*[_type == "project" && featured == true] | order(_createdAt desc) [0...4] {
  _id,
  title,
  slug,
  category,
  client,
  year,
  "coverImage": coverImage.asset->url,
  "gallery": gallery[].asset->url,
  videoUrl,
  summary,
  description,
  featured
}`

export const projectBySlugQuery = groq`*[_type == "project" && slug.current == $slug][0] {
  _id,
  title,
  slug,
  category,
  client,
  year,
  "coverImage": coverImage.asset->url,
  "gallery": gallery[].asset->url,
  videoUrl,
  summary,
  description,
  featured
}`
