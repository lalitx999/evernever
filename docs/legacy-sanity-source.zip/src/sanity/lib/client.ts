import { wordpressProjects } from '@/lib/cms/server'
import { createClient } from 'next-sanity'
import { apiVersion, dataset, projectId, useCdn } from '../env'
import { PROJECTS, type Project } from '@/data/projects'
import { projectsQuery } from './queries'

export const client = createClient({ projectId, dataset, apiVersion, useCdn })
const isSanityConfigured = projectId && projectId !== 'your-project-id'

export async function fetchProjects(): Promise<Project[]> {
  if (process.env.CONTENT_SOURCE === 'wordpress') return wordpressProjects()
  if (!isSanityConfigured) return PROJECTS
  try {
    const data = await client.fetch<Project[]>(projectsQuery)
    // Preserve the imported public portfolio while allowing CMS additions.
    const slugs = new Set(data.map(project => project.slug.current))
    return [...data, ...PROJECTS.filter(project => !slugs.has(project.slug.current))]
  } catch {
    console.warn('Sanity is unavailable; showing the imported Evernever portfolio.')
    return PROJECTS
  }
}
export async function fetchFeaturedProjects(): Promise<Project[]> {
  return (await fetchProjects()).filter(project => project.featured).slice(0, 4)
}
export async function fetchProjectBySlug(slug: string): Promise<Project | null> {
  return (await fetchProjects()).find(project => project.slug.current === slug) || null
}
